CHANGES
+++++++++
* 0.0.13 add more region information
* 0.0.12 fix bug: close context in download
* 0.0.11 fix bug: check http status code in download
* 0.0.10 fix bug: download signature expired
* 0.0.9  add new region: spg
* 0.0.8  fix bug
* 0.0.7  update documents
* 0.0.6  add tj region, enable_https changes to False
* 0.0.5  Optimization for uploadding file
* 0.0.4  Add traceback information, Add default logging handler
